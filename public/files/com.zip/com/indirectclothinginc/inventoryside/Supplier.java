package indirectclothinginc.inventoryside;

import indirectclothinginc.customerside.Customer;

public class Supplier {
 private String supplierName;
 private String supplierContact;
 private int leadTimeInDays;
 private boolean isAvailable;
 
 // Constructor woker
 // Constructor woker
   public Supplier(String supplierName, String supplierContact, int leadTimeInDays) {
      this.supplierName = supplierName;
      this.supplierContact = supplierContact; // Fixed this line
      this.leadTimeInDays = leadTimeInDays;
      this.isAvailable = true;
}
 
 // Getters and setters type shit mans
    public String getSupplierName() {
     return supplierName;
 }
 
  public String getSupplierContact() {
     return supplierContact;
 }
 
  public int getLeadTimeInDays() {
     return leadTimeInDays;
 }
 
  public boolean isAvailable() {
     return isAvailable;
 }
 
  public void setAvailable(boolean available) {
     isAvailable = available;
 }
 
 // Method to process a pre-order
  public boolean processPreOrder(String itemName, int quantity, Customer customer) {
     if (!isAvailable) {
         return false;
     }
     
     // Generate a pre-order ID ba bai
     int preOrderId = generatePreOrderId();
     
     // Log the pre-order details
     logPreOrder(preOrderId, itemName, quantity, customer);
     
     // Return estimated delivery information
     return true;
 }
 
 // Generate ng uniqlo na pre-order ID bai
 private int generatePreOrderId() {
     return (int)(Math.random() * 1000);
 }
 public void logPreOrder(int preOrderId, String itemName, int quantity, Customer customer) {
     System.out.println("\nPre-order processed:");
     System.out.println("Pre-order ID: " + preOrderId);
     System.out.println("Supplier: " + supplierName);
     System.out.println("Item: " + itemName);
     System.out.println("Quantity: " + quantity);
     System.out.println("Customer: " + customer.userName);
     System.out.println("Estimated delivery: " + leadTimeInDays + " days");
 }
 public void displayPreOrderConfirmation(String itemName, int quantity) {
     System.out.println("\n===== Pre-Order Confirmation =====");
     System.out.println("Your pre-order has been accepted!");
     System.out.println("Item: " + itemName);
     System.out.println("Quantity: " + quantity);
     System.out.println("Supplier: " + supplierName);
     System.out.println("Estimated delivery time: " + leadTimeInDays + " days");
     System.out.println("You will be contacted at " + supplierContact + " for updates.");
     System.out.println("==================================");
 }
}